ORBIT — YOUR AI WORKSPACE

QUICK START
1. Install Node.js 22 or newer: https://nodejs.org/
2. Extract the entire ZIP. Keep index.html, workspace.css, workspace.js,
   server.mjs, the logo files, and vendor/ together.
3. Copy .env.example to .env. Add your OpenRouter API key after
   OPENROUTER_API_KEY=. Never share your .env file.
4. Open a terminal in this folder and run:

   node --env-file=.env server.mjs

5. Open http://127.0.0.1:3000 in your browser. Enter the workspace.
6. Choose an available model, then send a message.

No npm install or build step is required. Do not open index.html directly:
the local server serves the styles, account library and API endpoints.
When upgrading, replace the site files but KEEP your existing .env file.
Restart Node and reload the browser after replacing the files.

WHAT'S INCLUDED
- OpenRouter model search, switching, streamed chat, stop, copy and export.
- Thinking control for models whose catalog declares reasoning support.
  It requests medium reasoning effort with an 8,192-token total output budget;
  ordinary chat uses 2,048 tokens. Thinking can take longer and cost more.
  The progress indicator is a working state, not a private reasoning transcript.
- Image paste/upload, previews, removal, and reference-image generation.
- Animated dimensional orbit artwork, Lucide icons, sidebar transitions.
- Dark, light and system themes; presets, custom accent color and RGB cycling.
- Reduced-motion controls and respect for the device's motion preference.
- First-entry intro, remembered locally or in the signed-in account.
- Delete individual chats or all conversations, with confirmation.
- Optional Google and Apple accounts with private cloud history/preferences.
- Transparent 1024 x 1024 Orbit PNG and scalable SVG.

IMAGES
In Chat, click + or paste a copied image/screenshot with Ctrl+V (Cmd+V on Mac).
Copy image bytes, not just its address. Choose PNG, JPEG or WebP, up to 2 MB
and 25 megapixels. One draft image is attached at a time; a new one replaces it.
Choose a model marked Image input to inspect images. Text-only models cannot.
Images remain in conversation context and are included in guest or cloud history.

Select Create image to choose from the dedicated image-generation catalog.
Write a prompt and optionally attach a reference if the selected model supports it.
Each request is independent; attach an earlier image to request an edit.
Generated PNG/JPEG/WebP images appear with download links. Download before refreshing:
generated image bytes are not stored in chat history. Prompts remain saved.
Stopping a generation does not guarantee the provider cancels billing.

ACCOUNTS — OPTIONAL SUPABASE SETUP
The local guest workspace works without Supabase. Login buttons remain disabled
until account configuration is present. No pretend/demo sign-in is used.

1. Create a Supabase project at https://supabase.com/ .
2. Run setup-database.sql in its SQL editor once. This creates orbit_workspaces
   and enables row-level security so each user can access only their own row.
3. In .env, set SUPABASE_URL to the HTTPS project origin (no trailing slash),
   and SUPABASE_ANON_KEY to the publishable key or legacy anon public key.
   NEVER use a service-role key or sb_secret key; those are rejected.
4. Enable Google and Apple in Supabase Authentication > Providers.
   Register/configure the corresponding apps in Google Cloud and Apple Developer.
   Put provider secrets in Supabase, never in browser code or this ZIP.
   Google: https://supabase.com/docs/guides/auth/social-login/auth-google
   Apple: https://supabase.com/docs/guides/auth/social-login/auth-apple
   Apple web sign-in needs an eligible Apple Developer configuration and domain;
   its OAuth client secret needs periodic renewal. Follow the provider docs.
5. Set the Supabase Site URL and redirect allowlist to your Orbit URL, ending in /.
   For local Google development, use http://127.0.0.1:3000/ and configure the
   provider's callback to the Supabase auth callback shown in its dashboard.
6. Restart Orbit, open Account, then continue with Google or Apple.

When accounts are configured, model requests require a verified signed-in session.
The site owner's OpenRouter key pays for requests. Guest history is never silently
uploaded into an account. Sign out to return to the separate local guest workspace.
Signed-in history is held in memory and saved to Supabase; session tokens use the
Supabase SDK's browser storage. Sign out on shared devices.
If a session ends unexpectedly, unsaved history, draft attachments and partial
replies get an owner-specific recovery copy in this tab's session storage (with
an in-memory fallback). Keep the tab open and sign back into that same account
to recover it. Recovery copies are unencrypted and do not transfer to other devices.

Cloud changes save automatically. Check Account for save status. If two devices
edit the same workspace, a revision conflict prevents silent overwriting. Export
the current conversation if needed, then choose Reload cloud history. Cloud
history loads on login/reload; this version is not a live collaboration app.
Deleting a chat/all chats updates the account after a successful cloud save.
History requests are capped at 12 MB. Export/delete older chats when needed.

HOSTING AND DEVICES
This package has not been deployed. Local mode binds to 127.0.0.1.
DevTools responsive sizing works on that local URL; actual other devices need
their own access to a hosted HTTPS URL.

To deploy, use a Node-capable HTTPS host:
- Deploy this whole folder, start command: node server.mjs.
- Set OPENROUTER_API_KEY, SUPABASE_URL and SUPABASE_ANON_KEY as hosting secrets.
- Set APP_ORIGIN to the exact HTTPS origin, without a trailing slash/path.
- Use the host's PORT variable. With APP_ORIGIN set, Orbit binds to 0.0.0.0.
- Add that URL to Supabase and provider redirect configuration.
- Restrict account registration to your intended users and set an OpenRouter
  key spending limit. The included 30-requests/hour/account limiter lives in
  process memory and resets on restart; it is not a billing quota.
This starter runs one model request at a time per server. A larger public service
needs a durable quota system, deployment monitoring and concurrency capacity.

The layout supports narrow phone widths, tablets, desktop and short landscape
viewports, with visible keyboard focus and touch-friendly main controls. Use a
modern browser. Actual Xbox/controller behavior and physical mobile keyboards
have not been tested. Browser file/clipboard support varies by device; use +
when image paste isn't supported. Animations reduce when requested by the OS.

PRIVACY AND COSTS
Messages/images go to OpenRouter and the selected model provider when sent.
Account history also goes to your Supabase project. Guest history stays in
unencrypted browser storage. Generated output is rendered as text, never executed.
Google Fonts supplies typography with local fallbacks. Image files are not stripped
of metadata. OpenRouter billing is separate from any ChatGPT subscription.
Only OpenRouter's available compatible models are shown, not every model in existence.
Audio generation, PDFs, model training and tool execution are not included.

VERIFICATION
To rerun the bundled checks: node tests/check_all.mjs
Local API tests cover chat streaming, image validation/forwarding, image generation,
session rejection, account ownership, save conflicts, reasoning metadata/payload,
static assets, duplicate HTML IDs and secret isolation. Provider responses are mocked.
Frontend regression tests also exercise session-switch races, stale attachment
callbacks, independent account saves and owner-specific draft/partial-reply recovery.
Browser checks cover onboarding, settings, themes, RGB, reduced motion, sidebar,
reasoning submission and responsive sizes. No paid requests were made.
Live Google/Apple OAuth and real model generation require your configured credentials.

THIRD-PARTY ASSETS
Lucide icons 0.468.0, ISC license: vendor/LUCIDE-LICENSE.txt.
Supabase JS 2.49.8, MIT license: vendor/SUPABASE-LICENSE.txt.
Both are vendored locally. Orbit's orbital mark is an original vector asset.

OpenRouter references:
https://openrouter.ai/docs/guides/overview/multimodal/image-understanding
https://openrouter.ai/docs/guides/overview/multimodal/image-generation
