'use strict';
// This classic script shares the existing chat controller's bindings.
const defaultPreferences={endpoint:'',system:'Be clear, helpful, and honest about uncertainty.',theme:'dark',accent:'#c9f27b',rgb:false,motion:'full',thinking:false,onboarded:false};
let accountConfig=null,authClient=null,accountUser=null,authReady=false,cloudReady=false,cloudRevision=0,cloudDirty=false,cloudSaving=false,cloudConflict=false,cloudTimer,accountEpoch=0;
let cloudSavingEpoch=-1;
const recoveries=new Map();
function rememberRecovery(owner){if(!owner)return;const snapshot=JSON.parse(JSON.stringify({payload:savedPayload(),revision:cloudRevision,draft:{text:$('prompt').value,image:attachment}}));const pending=window.orbitPendingResponse;if(pending?.epoch===accountEpoch&&pending.answer.content){const chat=snapshot.payload.chats.find(c=>c.id===pending.chatId);if(chat)chat.messages.push(JSON.parse(JSON.stringify(pending.answer)))}recoveries.set(owner,snapshot);try{sessionStorage.setItem('orbit-recovery-'+owner,JSON.stringify(snapshot))}catch{toast('Unsaved recovery is kept in this tab only. Keep the tab open and sign back in.')}}
function readRecovery(owner){if(recoveries.has(owner))return recoveries.get(owner);try{return JSON.parse(sessionStorage.getItem('orbit-recovery-'+owner)||'null')}catch{return null}}
function forgetRecovery(owner){recoveries.delete(owner);try{sessionStorage.removeItem('orbit-recovery-'+owner)}catch{}}
window.orbitEpoch=()=>accountEpoch;
function orbitCurrent(epoch){return epoch===accountEpoch}
const icon=name=>'<svg aria-hidden="true"><use href="#'+name+'"/></svg>';
const cleanChats=value=>Array.isArray(value)?value.filter(c=>c&&typeof c.id==='string'&&typeof c.title==='string'&&Array.isArray(c.messages)).map(c=>({...c,messages:c.messages.filter(m=>m&&['user','assistant'].includes(m.role)&&typeof m.content==='string')})):[];
const serializableChats=()=>chats.map(c=>({...c,messages:c.messages.map(({generated,...m})=>({...m,...(generated?{generatedMissing:true}:{})}))}));
const savedPayload=()=>({chats:serializableChats(),preferences});
const guestPreferences=()=>{try{return {...defaultPreferences,...JSON.parse(localStorage.getItem('orbit-preferences')||'{}')}}catch{return {...defaultPreferences}}};
preferences={...defaultPreferences,...preferences};

$('settingsDialog').insertAdjacentHTML('beforeend',`
 <section class="settings-section"><h3>${icon('palette')}Appearance</h3>
 <div class="theme-choices" aria-label="Theme"><button data-theme-choice="light">${icon('sun')}Light</button><button data-theme-choice="dark">${icon('moon')}Dark</button><button data-theme-choice="system">${icon('monitor')}System</button></div>
 <label for="accentColor">Accent color</label><div class="accent-row">
 <button class="swatch" style="--swatch:#c9f27b" data-accent="#c9f27b" aria-label="Lime accent"></button><button class="swatch" style="--swatch:#a5b8ff" data-accent="#a5b8ff" aria-label="Periwinkle accent"></button><button class="swatch" style="--swatch:#ffa9cc" data-accent="#ffa9cc" aria-label="Rose accent"></button><button class="swatch" style="--swatch:#78dcca" data-accent="#78dcca" aria-label="Teal accent"></button><button class="swatch" style="--swatch:#ffc685" data-accent="#ffc685" aria-label="Amber accent"></button><input id="accentColor" type="color" value="#c9f27b" aria-label="Custom accent color"></div>
 <label class="check-row"><input type="checkbox" id="rgbMode">RGB · slowly cycle accent colors</label>
 <label class="check-row"><input type="checkbox" id="reduceMotion">Reduce animations</label>
 <p class="settings-info">Appearance saves automatically. Your device's reduced-motion setting is always respected.</p>
 </section>
 <section class="settings-section"><h3>${icon('user')}Account & history</h3><p id="settingsAccountNote">Your conversations are saved in this browser.</p><div class="dialog-actions"><button class="secondary" id="settingsAccount">Manage account</button><button class="secondary" id="replayIntro">Replay welcome</button></div></section>`);
document.body.insertAdjacentHTML('beforeend',`
 <dialog id="accountDialog" aria-labelledby="accountTitle"><div class="dialog-head"><h2 id="accountTitle">Your space, everywhere.</h2><button class="iconbutton" id="closeAccount" aria-label="Close account">${icon('close')}</button></div>
 <p>Sign in to keep your conversations and preferences together across devices.</p>
 <div class="account-summary"><strong id="accountIdentity">Local workspace</strong><div class="cloud-status" id="cloudStatus" role="status">Checking account setup…</div></div>
 <div class="account-providers dialog-actions" id="providerButtons"><button class="secondary" id="googleLogin">Continue with Google</button><button class="secondary" id="appleLogin">Continue with Apple</button></div>
 <div class="dialog-actions"><button class="secondary" id="retryCloud" hidden>Retry save</button><button class="secondary" id="reloadCloud" hidden>Reload cloud history</button><button class="secondary danger" id="signOut" hidden>Sign out</button></div>
 <p class="settings-info" id="accountSetupNote">Google and Apple sign-in require the site owner's provider configuration. Local guest chats are kept separately from signed-in accounts.</p></dialog>
 <dialog id="introDialog" class="intro-dialog" aria-labelledby="introTitle"><div class="intro-layout"><div class="intro-art"><small>A SPACE FOR WHAT'S NEXT</small><div class="orbit-sculpture" aria-hidden="true"><i class="orbital-ring"></i><i class="orbital-ring"></i></div><div class="brand">${icon('orbit')}orbit</div></div><div class="intro-copy"><span class="intro-kicker">WELCOME TO YOUR WORKSPACE</span><h2 id="introTitle">Big ideas.<br><span>Room to orbit.</span></h2><p>A place to think out loud, make something new, and find your next direction. Your favorite AI models, together.</p><div class="intro-features"><span>${icon('chat')}Explore</span><span>${icon('image')}Create</span><span>${icon('brain')}Think</span></div><button class="primary" id="enterWorkspace">Enter workspace ${icon('arrow')}</button><button class="secondary" id="introAccount">Sign in to your account</button><p class="tiny">Make it yours in Settings. Colors, themes, and motion included.</p></div></div></dialog>`);

function cloudStatus(text){$('cloudStatus').textContent=text;$('accountCaption').textContent=accountUser?text:'Local guest · sign in'}
function updateAccountUI(){
 $('accountName').textContent=accountUser?(accountUser.user_metadata?.full_name||accountUser.email?.split('@')[0]||'Your account'):'Your workspace';
 $('accountIdentity').textContent=accountUser?accountUser.email||'Signed in':'Local workspace';
 $('providerButtons').hidden=!!accountUser;$('signOut').hidden=!accountUser;
 $('introAccount').hidden=!!accountUser;
 $('googleLogin').disabled=!authClient;$('appleLogin').disabled=!authClient;
 $('settingsAccountNote').textContent=accountUser?'Your signed-in history syncs to your account. Local guest chats stay separate.':'Your guest conversations are saved only in this browser.';
 $('settingsDialog').querySelector('.dialog-actions + p.tiny').textContent=accountUser?'Account history is saved to your Supabase workspace. Check Account for sync status before closing.':'Guest history is stored unencrypted in this browser. Avoid saving sensitive information on shared devices.';
 $('accountSetupNote').textContent=accountConfig?.authEnabled?'Your account history is stored in Supabase. Signing in does not upload existing guest chats. OpenRouter usage is billed to the site owner.':'Accounts are not configured yet. The site owner must add Supabase settings and enable Google and Apple providers. You can continue using the local workspace.';
}
function showAccount(){if(busy){toast('Stop the current response first.');return}$('settingsDialog').close();$('introDialog').close();$('accountDialog').showModal()}
$('accountButton').onclick=showAccount;$('settingsAccount').onclick=showAccount;$('closeAccount').onclick=()=>$('accountDialog').close();
function showIntro(force=false){if((force||!preferences.onboarded)&&!document.querySelector('dialog[open]'))$('introDialog').showModal()}
function finishIntro(){preferences.onboarded=true;persist();$('introDialog').close();$('prompt').focus({preventScroll:true})}
$('enterWorkspace').onclick=finishIntro;$('introDialog').addEventListener('cancel',e=>{e.preventDefault();finishIntro()});
$('introAccount').onclick=showAccount;$('replayIntro').onclick=()=>{$('settingsDialog').close();showIntro(true)};

const systemTheme=matchMedia('(prefers-color-scheme: light)'),systemMotion=matchMedia('(prefers-reduced-motion: reduce)');
let rgbTimer;
function setAccent(hex){
 if(!/^#[a-f\d]{6}$/i.test(hex))hex='#c9f27b';
 const rgb=[1,3,5].map(i=>parseInt(hex.slice(i,i+2),16)/255),linear=rgb.map(v=>v<=.04045?v/12.92:((v+.055)/1.055)**2.4),l=linear[0]*.2126+linear[1]*.7152+linear[2]*.0722;
 document.documentElement.style.setProperty('--accent',hex);document.documentElement.style.setProperty('--on-accent',l>.179?'#101810':'#ffffff');
 // Color on text needs contrast independently of filled buttons.
 const light=document.documentElement.dataset.theme==='light';
 const adjusted=light&&l>.14?rgb.map(v=>v*.46):!light&&l<.22?rgb.map(v=>v*.4+.6):rgb;
 document.documentElement.style.setProperty('--accent-ink','#'+adjusted.map(v=>Math.round(v*255).toString(16).padStart(2,'0')).join(''));
}
function hslHex(h){const s=.65,l=.72,a=s*Math.min(l,1-l),f=n=>{const k=(n+h/30)%12;return Math.round(255*(l-a*Math.max(-1,Math.min(k-3,9-k,1)))).toString(16).padStart(2,'0')};return '#'+f(0)+f(8)+f(4)}
function applyAppearance(){
 const theme=['light','dark','system'].includes(preferences.theme)?preferences.theme:'dark';document.documentElement.dataset.theme=theme==='system'?(systemTheme.matches?'light':'dark'):theme;
 document.documentElement.dataset.motion=preferences.motion==='reduced'||systemMotion.matches?'reduced':'full';
 setAccent(preferences.accent||'#c9f27b');clearInterval(rgbTimer);
 if(preferences.rgb&&document.documentElement.dataset.motion!=='reduced'){let hue=85;rgbTimer=setInterval(()=>{if(!document.hidden)setAccent(hslHex(hue=(hue+.7)%360))},100)}
 document.querySelectorAll('[data-theme-choice]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.themeChoice===theme)));
 document.querySelectorAll('[data-accent]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.accent===preferences.accent)));
 $('accentColor').value=/^#[a-f\d]{6}$/i.test(preferences.accent)?preferences.accent:'#c9f27b';$('rgbMode').checked=!!preferences.rgb;$('reduceMotion').checked=preferences.motion==='reduced';
}
document.querySelectorAll('[data-theme-choice]').forEach(b=>b.onclick=()=>{preferences.theme=b.dataset.themeChoice;applyAppearance();persist()});
document.querySelectorAll('[data-accent]').forEach(b=>b.onclick=()=>{preferences.accent=b.dataset.accent;preferences.rgb=false;applyAppearance();persist()});
$('accentColor').oninput=()=>{preferences.accent=$('accentColor').value;preferences.rgb=false;applyAppearance();persist()};
$('rgbMode').onchange=()=>{preferences.rgb=$('rgbMode').checked;applyAppearance();persist()};$('reduceMotion').onchange=()=>{preferences.motion=$('reduceMotion').checked?'reduced':'full';applyAppearance();persist()};systemTheme.addEventListener('change',applyAppearance);systemMotion.addEventListener('change',applyAppearance);

function updateThinking(){const supported=mode==='chat'&&available.find(m=>m.name===selected)?.reasoning;const b=$('thinkingToggle');b.disabled=busy||!supported;b.setAttribute('aria-pressed',String(!!preferences.thinking&&!!supported));b.title=supported?'Allow more reasoning time. May use more tokens and credits.':'Choose a chat model with reasoning support';}
$('thinkingToggle').onclick=()=>{preferences.thinking=!preferences.thinking;updateThinking();persist();toast(preferences.thinking?'Thinking enabled · more time and tokens may be used':'Thinking disabled')};
const baseChoose=choose;choose=function(...args){const r=baseChoose(...args);updateThinking();return r};
const baseConnect=connect;connect=async function(...args){await baseConnect(...args);updateThinking()};
const baseChangeMode=changeMode;changeMode=async function(...args){await baseChangeMode(...args);updateThinking()};
const baseBusy=setBusy;setBusy=function(value){baseBusy(value);updateThinking()};
$('connect').onclick=connect;

const mobileLayout=matchMedia('(max-width: 760px)');
function syncSidebar(){const open=$('sidebar').classList.contains('open');$('sidebarShade').classList.toggle('visible',(window.innerWidth<=760)&&open);$('menu').setAttribute('aria-expanded',String((window.innerWidth<=760)?open:!document.body.classList.contains('sidebar-collapsed')));$('sidebar').inert=(window.innerWidth<=760)?!open:document.body.classList.contains('sidebar-collapsed');if((window.innerWidth<=760))document.body.classList.remove('sidebar-collapsed')}
function closeSidebar(){const restore=$('sidebar').contains(document.activeElement);$('sidebar').classList.remove('open');syncSidebar();if(restore)$('menu').focus()}
$('menu').onclick=()=>{if((window.innerWidth<=760)){const open=!$('sidebar').classList.contains('open');$('sidebar').classList.toggle('open',open);syncSidebar();if(open)$('newChat').focus()}else{document.body.classList.toggle('sidebar-collapsed');syncSidebar()}};
$('sidebarClose').onclick=closeSidebar;$('sidebarShade').onclick=closeSidebar;
new MutationObserver(syncSidebar).observe($('sidebar'),{attributes:true,attributeFilter:['class']});mobileLayout.addEventListener('change',syncSidebar);window.addEventListener('resize',syncSidebar);
document.addEventListener('keydown',e=>{if(!(window.innerWidth<=760)||!$('sidebar').classList.contains('open')||document.querySelector('dialog[open]'))return;if(e.key==='Escape'){closeSidebar();return}if(e.key==='Tab'){const buttons=[...$('sidebar').querySelectorAll('button:not(:disabled)')].filter(b=>b.offsetParent!==null),first=buttons[0],last=buttons.at(-1);if(e.shiftKey&&document.activeElement===first){e.preventDefault();last.focus()}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus()}}});
const baseRenderHistory=renderHistory;renderHistory=function(){baseRenderHistory();[...$('history').children].forEach((button,i)=>{if(button.tagName!=='BUTTON')return;const chat=chats[i];const row=document.createElement('div');row.className='history-row';button.replaceWith(row);row.append(button);const del=document.createElement('button');del.className='delete-chat';del.innerHTML=icon('trash');del.setAttribute('aria-label','Delete '+chat.title);del.onclick=()=>{if(busy){toast('Stop the response first.');return}if(!confirm('Delete this conversation? This cannot be undone.'))return;chats=chats.filter(c=>c.id!==chat.id);if(active===chat.id)active=null;persist();renderHistory();renderChat();toast('Conversation deleted')};row.append(del)})};
$('clearHistory').onclick=()=>{if(busy){toast('Stop generation first.');return}if(confirm(accountUser?'Delete all conversations in this account? Other signed-in devices will see the deletion after reloading.':'Delete all guest conversations from this browser?')){chats=[];active=null;persist();renderHistory();renderChat();toast(accountUser?'Conversations cleared. Check account status for cloud save.':'Guest history deleted')}};

async function orbitRequestHeaders(expectedOwner=accountUser?.id??null,expectedEpoch=accountEpoch){const headers={'Content-Type':'application/json'};if(authClient){const {data,error}=await authClient.auth.getSession();if(error)throw error;if(expectedEpoch!==accountEpoch||(data.session?.user?.id??null)!==expectedOwner)throw Error('The account changed before this request.');if(data.session)headers.Authorization='Bearer '+data.session.access_token}if(expectedEpoch!==accountEpoch)throw Error('The account changed before this request.');return headers}
window.orbitBeforeSend=async()=>{if(busy)return true;if(!authReady){toast('Account setup is still loading. Please wait.');return false}if(accountConfig?.authEnabled&&!accountUser){showAccount();return false}if(accountUser&&!cloudReady){showAccount();toast('Load your account history before sending.');return false}return true};
persist=function(){
 if(accountUser){if(!cloudReady)return;cloudDirty=true;cloudStatus(cloudConflict?'Cloud conflict · reload required':'Unsaved changes');clearTimeout(cloudTimer);cloudTimer=setTimeout(saveCloud,500);return}
 try{localStorage.setItem('orbit-chats',JSON.stringify(serializableChats()));localStorage.setItem('orbit-preferences',JSON.stringify(preferences))}catch{toast('Browser storage is full or unavailable. Export your chat to keep it.')}
};
async function saveCloud(){
 if(!accountUser||!cloudReady||(cloudSaving&&cloudSavingEpoch===accountEpoch)||cloudConflict||!cloudDirty)return;
 const epoch=accountEpoch,owner=accountUser.id,revision=cloudRevision,payload=savedPayload();cloudSavingEpoch=epoch;cloudSaving=true;cloudDirty=false;cloudStatus('Saving to your account…');
 try{const headers=await orbitRequestHeaders(owner,epoch);if(epoch!==accountEpoch||owner!==accountUser?.id)return;const r=await fetch('/api/state',{method:'PUT',headers,body:JSON.stringify({payload,revision}),signal:AbortSignal.timeout(20000)});const data=await r.json();if(epoch!==accountEpoch)return;if(!r.ok){if(r.status===409)cloudConflict=true;throw Error(data.error||'Cloud save failed.')}cloudRevision=data.revision;forgetRecovery(owner);cloudStatus(cloudDirty?'Unsaved changes':'Saved to your account');$('retryCloud').hidden=true;$('reloadCloud').hidden=true;}
 catch(e){if(epoch!==accountEpoch)return;cloudDirty=true;cloudStatus(e.message);$('retryCloud').hidden=cloudConflict;$('reloadCloud').hidden=!cloudConflict;toast(cloudConflict?'Another device changed this workspace. Open Account to reload.':'Cloud save failed. Open Account to retry, or export your chat.');}
 finally{if(cloudSavingEpoch===epoch)cloudSaving=false;if(accountUser&&cloudReady&&cloudDirty&&!cloudSaving&&!cloudConflict&&$('retryCloud').hidden)setTimeout(saveCloud,500)}
}
async function loadCloud(discardRecovery=false){
 const epoch=accountEpoch,owner=accountUser?.id;cloudReady=false;cloudStatus('Loading your account…');
 try{const headers=await orbitRequestHeaders(owner,epoch);if(epoch!==accountEpoch)return;const r=await fetch('/api/state',{headers,signal:AbortSignal.timeout(20000)});const data=await r.json();if(epoch!==accountEpoch)return;if(!r.ok)throw Error(data.error||'Could not load cloud history');if(discardRecovery)forgetRecovery(owner);const recovery=readRecovery(owner);const payload=recovery?.payload||data.payload;chats=cleanChats(payload?.chats);preferences={...defaultPreferences,...(payload?.preferences||{})};cloudRevision=data.revision;cloudConflict=!!recovery&&recovery.revision!==data.revision;cloudDirty=!!recovery;cloudReady=true;active=null;$('prompt').value=recovery?.draft?.text||'';attachment=recovery?.draft?.image||null;renderAttachment();renderHistory();renderChat();applyAppearance();updateThinking();cloudStatus(recovery?(cloudConflict?'Recovered unsaved changes · cloud conflict. Export before reloading.':'Recovered unsaved changes · saving…'):'Saved to your account');$('reloadCloud').hidden=!cloudConflict;$('retryCloud').hidden=true;if(cloudDirty&&!cloudConflict)saveCloud();showIntro();}
 catch(e){if(epoch!==accountEpoch)return;cloudStatus(e.message);$('reloadCloud').hidden=false;$('retryCloud').hidden=true;toast('Account history could not load. Open Account to retry.');}
}
$('retryCloud').onclick=()=>saveCloud();$('reloadCloud').onclick=()=>{if(busy||cloudSaving){toast('Wait for the current operation first.');return}if(cloudDirty&&!confirm('Replace this session with the cloud version? Export your current chat first if you want to keep it.'))return;loadCloud(true)};
async function setAccount(session){
 const next=session?.user||null;if(next?.id===accountUser?.id)return;
 if(accountUser&&(cloudDirty||cloudSaving||busy||$('prompt').value.trim()||attachment)){rememberRecovery(accountUser.id);toast('Unsaved work was kept for your previous account. Sign back in before closing this tab.');}
 controller?.abort();controller=null;window.orbitPendingResponse=null;accountEpoch++;clearTimeout(cloudTimer);cloudSaving=false;cloudDirty=false;cloudConflict=false;cloudReady=false;accountUser=next;attachment=null;loadingImage=false;setBusy(false);$('prompt').value='';active=null;chats=[];renderAttachment();renderHistory();renderChat();
 updateAccountUI();if(next){$('accountDialog').close();$('introDialog').close();await loadCloud()}else{preferences=guestPreferences();try{chats=cleanChats(JSON.parse(localStorage.getItem('orbit-chats')||'[]'))}catch{chats=[]}applyAppearance();renderHistory();renderChat();updateThinking();cloudStatus('Local guest · sign in');showIntro()}
}
async function signIn(provider){if(!authClient)return;cloudStatus('Opening '+(provider==='google'?'Google':'Apple')+' sign-in…');const {error}=await authClient.auth.signInWithOAuth({provider,options:{redirectTo:location.origin+'/'}});if(error)cloudStatus(error.message)}
$('googleLogin').onclick=()=>signIn('google').catch(e=>cloudStatus(e.message));$('appleLogin').onclick=()=>signIn('apple').catch(e=>cloudStatus(e.message));
$('signOut').onclick=async()=>{if(busy||cloudSaving){toast('Wait for the current operation before signing out.');return}if(cloudDirty){await saveCloud();if(cloudDirty){toast('Save or export your changes before signing out.');return}}const {error}=await authClient.auth.signOut({scope:'local'});if(error){cloudStatus(error.message);return}await setAccount(null);$('accountDialog').close()};
async function initializeAccounts(){
 try{if(location.protocol==='file:')throw Error('Start the Orbit server to connect.');const r=await fetch('/api/config',{signal:AbortSignal.timeout(10000)});if(!r.ok)throw Error('Account configuration unavailable. Restart the updated server.');accountConfig=await r.json();
 if(accountConfig.authEnabled){await new Promise((resolve,reject)=>{const script=document.createElement('script');script.src='/vendor/supabase.js';script.onload=resolve;script.onerror=()=>reject(Error('The account library could not load.'));document.head.append(script)});authClient=window.supabase.createClient(accountConfig.supabaseUrl,accountConfig.supabaseKey,{auth:{flowType:'pkce',detectSessionInUrl:true,persistSession:true}});authClient.auth.onAuthStateChange((event,session)=>{setTimeout(()=>setAccount(session),0)});const {data,error}=await authClient.auth.getSession();if(error)throw error;await setAccount(data.session);if(!data.session)cloudStatus('Sign in to use your account');}
 else cloudStatus('Accounts not configured · local workspace available');
 authReady=true;updateAccountUI();if(!accountUser)showIntro();
 }catch(e){authReady=false;cloudStatus(e.message);updateAccountUI();toast(e.message);showIntro()}
}
window.addEventListener('beforeunload',e=>{if(recoveries.size||(accountUser&&(cloudDirty||cloudSaving))){e.preventDefault();e.returnValue=''}});
document.addEventListener('visibilitychange',()=>{if(document.hidden&&cloudDirty)saveCloud()});
applyAppearance();syncSidebar();renderHistory();updateThinking();initializeAccounts();
// The initial catalog request was started by the main script before this extension loaded.
const catalogObserver=new MutationObserver(updateThinking);catalogObserver.observe($('selectedName'),{childList:true});
