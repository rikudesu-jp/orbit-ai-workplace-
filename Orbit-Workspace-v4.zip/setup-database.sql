-- Run once in your Supabase SQL editor. Uses the authenticated user's identity.
create table if not exists public.orbit_workspaces (
  user_id uuid primary key references auth.users(id) on delete cascade,
  payload jsonb not null default '{}'::jsonb,
  revision integer not null default 1 check (revision > 0)
);
alter table public.orbit_workspaces enable row level security;
revoke all on public.orbit_workspaces from anon;
grant select, insert, update, delete on public.orbit_workspaces to authenticated;
create policy "Own workspace only" on public.orbit_workspaces
  for all to authenticated
  using ((select auth.uid()) = user_id)
  with check ((select auth.uid()) = user_id);
