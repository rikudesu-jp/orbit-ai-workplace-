import assert from 'node:assert/strict';
import vm from 'node:vm';
import {readFile} from 'node:fs/promises';
const source=await readFile(new URL('../workspace.js',import.meta.url),'utf8');
const extract=(start,end)=>source.slice(source.indexOf(start),source.indexOf(end));
const headers=extract('async function orbitRequestHeaders','window.orbitBeforeSend');
const save=extract('async function saveCloud(){','async function loadCloud(');
const transition=extract('async function setAccount(session){','async function signIn(');
const recovery=extract('function rememberRecovery(owner)','window.orbitEpoch=');
const deferred=()=>{let resolve;const promise=new Promise(r=>resolve=r);return {promise,resolve}};
function fixture(){
 const nodes=new Map(),storage=new Map(),calls=[],timers=[];
 const c={accountUser:{id:'A'},accountEpoch:1,cloudReady:true,cloudDirty:true,cloudSaving:false,cloudSavingEpoch:-1,cloudConflict:false,cloudRevision:1,cloudTimer:0,controller:null,busy:false,loadingImage:false,attachment:null,active:null,chats:[{id:'a',messages:[]}],preferences:{},defaultPreferences:{},recoveries:new Map(),calls,timers,
  window:{},$:id=>{if(!nodes.has(id))nodes.set(id,{hidden:true,value:'',close(){}});return nodes.get(id)},
  savedPayload:()=>({chats:structuredClone(c.chats),preferences:{}}),
  sessionStorage:{setItem:(k,v)=>storage.set(k,v),getItem:k=>storage.get(k),removeItem:k=>storage.delete(k)},
  localStorage:{getItem:()=>null},guestPreferences:()=>({}),cleanChats:x=>x||[],
  cloudStatus(){},toast(){},renderAttachment(){},renderHistory(){},renderChat(){},updateAccountUI(){},applyAppearance(){},updateThinking(){},showIntro(){},setBusy(v){c.busy=v},async loadCloud(){c.cloudReady=true},
  setTimeout:fn=>{timers.push(fn);return timers.length},clearTimeout(){},AbortSignal,
  authClient:{auth:{getSession:async()=>({data:{session:{user:{id:c.accountUser.id},access_token:c.accountUser.id}}})}},
  fetch:async(url,opts)=>{calls.push({url,...opts});return {ok:true,json:async()=>({revision:2})}},
 };
 vm.createContext(c);vm.runInContext(recovery+headers+save+transition,c);return c;
}
// A token lookup that finishes after switching accounts must not submit old data.
{
 const c=fixture(),wait=deferred();c.authClient.auth.getSession=()=>wait.promise;
 const job=c.saveCloud();c.accountEpoch=2;c.accountUser={id:'B'};wait.resolve({data:{session:{user:{id:'B'},access_token:'B'}}});await job;
 assert.equal(c.calls.length,0,'Old payload must never be sent under the new token');
}
// A's delayed request must not clear B's in-flight flag or suppress B's save.
{
 const c=fixture(),a=deferred(),b=deferred(),startedA=deferred(),startedB=deferred();
 c.fetch=(url,opts)=>{c.calls.push(opts);if(opts.headers.Authorization==='Bearer A'){startedA.resolve();return a.promise}startedB.resolve();return b.promise};
 const saveA=c.saveCloud();await startedA.promise;
 await c.setAccount({user:{id:'B'}});c.cloudDirty=true;const saveB=c.saveCloud();await startedB.promise;
 a.resolve({ok:true,json:async()=>({revision:2})});await saveA;assert.equal(c.cloudSaving,true);assert.equal(c.cloudSavingEpoch,2);
 b.resolve({ok:true,json:async()=>({revision:2})});await saveB;assert.equal(c.cloudSaving,false);assert.equal(c.calls.length,2);
}
// Involuntary sign-out keeps owner-scoped recovery and clears the visible workspace.
{
 const c=fixture();await c.setAccount(null);assert.equal(c.accountUser,null);assert.equal(c.chats.length,0);assert.equal(c.readRecovery('A').payload.chats[0].id,'a');assert.equal(c.readRecovery('B'),null);
}
// Failed-send drafts and partial streamed output belong to the previous owner too.
{
 const c=fixture();c.cloudDirty=false;c.$('prompt').value='Retry my draft';c.attachment={name:'test.png',url:'data:image/png;base64,test'};c.window.orbitPendingResponse={epoch:1,chatId:'a',answer:{role:'assistant',content:'Partial answer'}};
 await c.setAccount(null);const recovery=c.readRecovery('A');assert.equal(recovery.draft.text,'Retry my draft');assert.equal(recovery.draft.image.name,'test.png');assert.equal(recovery.payload.chats[0].messages[0].content,'Partial answer');assert.equal(c.$('prompt').value,'');assert.equal(c.attachment,null);
 c.accountUser={id:'A'};c.fetch=async()=>({ok:true,json:async()=>({payload:{chats:[],preferences:{}},revision:2})});
 vm.runInContext(extract('async function loadCloud(',"$('retryCloud').onclick="),c);await c.loadCloud();assert.equal(c.$('prompt').value,'Retry my draft');assert.equal(c.attachment.name,'test.png');assert.equal(c.cloudConflict,true);
}
console.log('PASS: account-switch token race, independent in-flight saves, owner-scoped sign-out recovery. Tests execute the actual frontend functions.');
