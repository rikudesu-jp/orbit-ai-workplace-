import assert from 'node:assert/strict';
import {createApp} from '../server.mjs';
const b64='iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jRZkAAAAASUVORK5CYII=';
let payload;
const server=createApp({key:'mock',request:async(url,opts)=>{
 if(url.endsWith('/images/models'))return Response.json({data:[{id:'test/image',name:'Image',architecture:{input_modalities:['text','image'],output_modalities:['image']}}]});
 payload=JSON.parse(opts.body);return Response.json({data:[{b64_json:b64,media_type:'image/png'}],usage:{cost:0.01}});
}});
await new Promise(r=>server.listen(0,'127.0.0.1',r));const base='http://127.0.0.1:'+server.address().port;
try{
 const catalog=await fetch(base+'/api/image-models');assert.equal(catalog.status,200);assert.equal((await catalog.json()).models[0].vision,true);
 const send=x=>fetch(base+'/api/images',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(x)});
 const res=await send({model:'test/image',prompt:'A blue square',image:'data:image/png;base64,'+b64});assert.equal(res.status,200);assert.equal((await res.json()).images[0].url,'data:image/png;base64,'+b64);assert.equal(payload.input_references[0].image_url.url,'data:image/png;base64,'+b64);
 assert.equal((await send({model:'test/image',prompt:''})).status,400);
 console.log('PASS: image catalog, generation, reference image forwarding, result normalization, empty prompt rejection. Provider mocked.');
}finally{await new Promise(r=>server.close(r))}
