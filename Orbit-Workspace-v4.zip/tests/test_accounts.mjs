import assert from 'node:assert/strict';
import {createApp} from '../server.mjs';
let lastPayload, lastStateUrl, stateWrite, conflict=false;
const request=async(url,options={})=>{
 if(url.endsWith('/auth/v1/user'))return ['Bearer good','Bearer other'].includes(options.headers.Authorization)?Response.json({id:options.headers.Authorization==='Bearer good'?'user-a':'user-b',email:'a@example.test'}):Response.json({}, {status:401});
 if(url.includes('/rest/v1/orbit_workspaces')){lastStateUrl=url;if(options.body)stateWrite=JSON.parse(options.body);return Response.json(conflict?[]:[{payload:{chats:[],preferences:{}},revision:1}]);}
 if(url.endsWith('/models'))return Response.json({data:[{id:'reason/test',name:'Reason',architecture:{output_modalities:['text']},supported_parameters:['reasoning']}]});
 lastPayload=JSON.parse(options.body);return new Response('data: {"choices":[{"delta":{"content":"Answer"}}]}\n\ndata: [DONE]\n\n');
};
const server=createApp({key:'mock',request,supabaseUrl:'https://test.supabase.co',supabaseKey:'public-test'});
await new Promise(r=>server.listen(0,'127.0.0.1',r));const base='http://127.0.0.1:'+server.address().port;
const post=(path,body,token)=>fetch(base+path,{method:'POST',headers:{'Content-Type':'application/json',...(token?{Authorization:'Bearer '+token}:{})},body:JSON.stringify(body)});
try{
 const config=await(await fetch(base+'/api/config')).json();assert.equal(config.authEnabled,true);
 const body={model:'reason/test',messages:[{role:'user',content:'hello'}],thinking:true};
 assert.equal((await post('/api/chat',body)).status,401);
 assert.equal((await post('/api/chat',body,'bad')).status,401);
 assert.equal((await fetch(base+'/api/state',{headers:{Authorization:'Bearer good'}})).status,200);assert.match(lastStateUrl,/user_id=eq.user-a/);
 assert.equal((await fetch(base+'/api/state',{headers:{Authorization:'Bearer other'}})).status,200);assert.match(lastStateUrl,/user_id=eq.user-b/);
 const save=data=>fetch(base+'/api/state',{method:'PUT',headers:{Authorization:'Bearer good','Content-Type':'application/json'},body:JSON.stringify(data)});
 assert.equal((await save({user_id:'user-b',revision:0,payload:{chats:[],preferences:{}}})).status,200);assert.equal(stateWrite.user_id,'user-a');assert.equal(stateWrite.revision,1);
 assert.equal((await save({revision:1,payload:{chats:[],preferences:{}}})).status,200);assert.match(lastStateUrl,/user_id=eq.user-a&revision=eq.1/);
 conflict=true;assert.equal((await save({revision:1,payload:{chats:[],preferences:{}}})).status,409);conflict=false;
 assert.equal((await save({revision:-1,payload:{chats:[],preferences:{}}})).status,400);
 assert.equal((await(await fetch(base+'/api/models')).json()).models[0].reasoning,true);
 const reply=await post('/api/chat',body,'good');assert.equal(reply.status,200);await reply.text();assert.equal(lastPayload.reasoning.effort,'medium');assert.equal(lastPayload.reasoning.exclude,true);
 assert.equal((await fetch(base+'/workspace.css')).status,200);
 assert.equal((await fetch(base+'/.env')).status,404);
 assert.throws(()=>createApp({appOrigin:'https://orbit.example',supabaseUrl:'',supabaseKey:''}),/authentication/);
 assert.throws(()=>createApp({supabaseUrl:'https://test.supabase.co',supabaseKey:'sb_secret_test'}),/never/);
 console.log('PASS: account config, missing/invalid session rejection, account-owned state, reasoning metadata and payload, assets, secrets. Mocked providers.');
}finally{await new Promise(r=>server.close(r));}
