import assert from 'node:assert/strict';
import {createApp} from '../server.mjs';
const png='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jRZkAAAAASUVORK5CYII=';
let sent;
const app=createApp({key:'test-only',request:async(url,opts)=>{
 if(url.endsWith('/models'))return Response.json({data:[{id:'vision',name:'Vision',architecture:{input_modalities:['text','image'],output_modalities:['text']}}]});
 sent=JSON.parse(opts.body);return new Response('data: {"choices":[{"delta":{"content":"A pixel."}}]}\n\ndata: [DONE]\n\n');
}});
await new Promise(r=>app.listen(0,'127.0.0.1',r));
const base='http://127.0.0.1:'+app.address().port;
const post=content=>fetch(base+'/api/chat',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({model:'vision',messages:[{role:'user',content}]})});
try{
 const catalog=await(await fetch(base+'/api/models')).json();assert.equal(catalog.models[0].vision,true);
 const content=[{type:'text',text:'Describe this image.'},{type:'image_url',image_url:{url:png}}];
 const res=await post(content);assert.equal(res.status,200);await res.text();assert.deepEqual(sent.messages[0].content,content);
 assert.equal((await post([{type:'image_url',image_url:{url:'https://example.com/pic.png'}}])).status,400);
 assert.equal((await post([{type:'image_url',image_url:{url:'data:image/svg+xml;base64,PHN2Zz4='}}])).status,400);
 assert.equal((await post([{type:'image_url',image_url:{url:'data:image/png;base64,bm90IGFuIGltYWdl'}}])).status,400);
 console.log('PASS: image capability catalog, multimodal forwarding, invalid image content and unsupported formats rejected; provider mocked.');
}finally{await new Promise(r=>app.close(r))}
