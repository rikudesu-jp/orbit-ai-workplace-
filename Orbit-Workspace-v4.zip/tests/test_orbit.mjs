import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import vm from 'node:vm';
import {createApp} from '../server.mjs';
const html=await readFile(new URL('../index.html',import.meta.url),'utf8');
new vm.Script(html.match(/<script>([\s\S]*?)<\/script>/)[1]);
new vm.Script(await readFile(new URL('../workspace.js',import.meta.url),'utf8'));
const ids=[...html.matchAll(/\bid="([^"]+)"/g)].map(m=>m[1]);
assert.equal(new Set(ids).size,ids.length,'HTML IDs must be unique, including SVG symbols and controls');
let upstreamCalls=0;
const request=async(url,options)=>{
 if(url.endsWith('/models'))return Response.json({data:[{id:'test/chat',name:'Test chat',architecture:{output_modalities:['text']},pricing:{prompt:'0',completion:'0'}},{id:'test/image',architecture:{output_modalities:['image']}}]});
 upstreamCalls++;assert.equal(options.headers.Authorization,'Bearer test-only-key');
 const input=JSON.parse(options.body);assert.equal(input.model,'test/chat');assert.equal(input.max_tokens,2048);
 return new Response('data: {"choices":[{"delta":{"content":"Hello "}}]}\r\n\r\n: heartbeat\n\ndata: {"choices":[{"delta":{"content":"world"}}]}\n\ndata: [DONE]\n\n');
};
async function withServer(key,fn){const server=createApp({key,request});await new Promise(r=>server.listen(0,'127.0.0.1',r));try{await fn('http://127.0.0.1:'+server.address().port)}finally{await new Promise(r=>server.close(r))}}
const payload={model:'test/chat',messages:[{role:'user',content:'hello'}]};
await withServer('',async base=>{
 assert.equal((await fetch(base)).status,200);
 assert.equal((await(await fetch(base+'/api/status')).json()).configured,false);
 assert.equal((await fetch(base+'/api/chat',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)})).status,503);
 assert.equal((await fetch(base+'/.env')).status,404);
});
await withServer('test-only-key',async base=>{
 const data=await(await fetch(base+'/api/models')).json();assert.equal(data.models.length,1);assert.equal(data.configured,true);assert(!JSON.stringify(data).includes('test-only-key'));
 const response=await fetch(base+'/api/chat',{method:'POST',headers:{'Content-Type':'application/json',Origin:base},body:JSON.stringify(payload)});
 assert.equal(response.status,200);assert.deepEqual((await response.text()).trim().split('\n').map(JSON.parse).map(x=>x.message.content),['Hello ','world']);
 assert.equal((await fetch(base+'/api/chat',{method:'POST',headers:{'Content-Type':'application/json',Origin:'https://untrusted.example'},body:JSON.stringify(payload)})).status,403);
 assert.equal((await fetch(base+'/api/chat',{method:'POST',headers:{'Content-Type':'application/json'},body:'{}'})).status,400);
});
assert.equal(upstreamCalls,1);
console.log('PASS: frontend syntax, page serving, catalog filtering, missing key, secret isolation, streaming conversion, origin and input validation. Upstream requests mocked; no paid calls.');
