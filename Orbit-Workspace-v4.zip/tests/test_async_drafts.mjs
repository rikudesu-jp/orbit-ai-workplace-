import assert from 'node:assert/strict';
import vm from 'node:vm';
import {readFile} from 'node:fs/promises';
const html=await readFile(new URL('../index.html',import.meta.url),'utf8');
const generate=html.slice(html.indexOf('async function generateImage(){'),html.indexOf('\nrenderFeatured();renderHistory();renderChat();'));
const attach=html.slice(html.indexOf('async function attachFile(file){'),html.indexOf("$('attachImage').onclick="));
const deferred=()=>{let resolve,reject;const promise=new Promise((a,b)=>{resolve=a;reject=b});return {promise,resolve,reject}};
function fixture(){const nodes=new Map();const c={epoch:1,busy:false,loadingImage:false,connected:true,preferences:{},chats:[{id:'old-chat',messages:[]}],active:'old-chat',selected:'chat-model',attachment:{name:'old.png',url:'data:image/png;base64,test'},imageModels:[{name:'image-model',vision:true}],imageSelection:'image-model',controller:null,saves:0,
 $:id=>{if(!nodes.has(id))nodes.set(id,{value:'',disabled:false,hidden:false});return nodes.get(id)},window:{orbitEpoch:()=>c.epoch},orbitCurrent:e=>e===c.epoch,orbitRequestHeaders:async()=>({}),
 renderAttachment(){},renderChat(){},renderHistory(){},appendMessage(){return {}},setBusy:v=>c.busy=v,persist:()=>c.saves++,toast(){},setTimeout:()=>1,clearTimeout(){},AbortController,Blob,Uint8Array,
 };vm.createContext(c);vm.runInContext(generate+attach,c);return c;}
{
 const c=fixture(),request=deferred(),started=deferred();c.fetch=()=>{started.resolve();return request.promise};c.$('prompt').value='Old owner prompt';const job=c.generateImage();await started.promise;
 c.epoch=2;c.chats=[];c.attachment=null;c.$('prompt').value='New owner draft';c.busy=false;const saved=c.saves;
 request.reject(new Error('Old request aborted'));await job;assert.equal(c.$('prompt').value,'New owner draft');assert.equal(c.attachment,null);assert.equal(c.saves,saved);
}
{
 const c=fixture(),decode=deferred(),started=deferred();c.attachment=null;
 c.FileReader=class{readAsDataURL(){this.result='data:image/png;base64,test';this.onload()}};
 c.Image=class{naturalWidth=1;naturalHeight=1;decode(){started.resolve();return decode.promise}};
 const file=new Blob([Uint8Array.from([137,80,78,71,13,10,26,10,0,0,0,0])],{type:'image/png'});
 const job=c.attachFile(file);await started.promise;c.epoch=2;c.loadingImage=false;decode.resolve();await job;assert.equal(c.attachment,null);assert.equal(c.loadingImage,false);
}
console.log('PASS: stale image-generation failure cannot restore another owner’s draft; stale decoded clipboard image cannot cross accounts.');
