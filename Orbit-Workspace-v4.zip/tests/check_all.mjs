for(const file of ['test_orbit.mjs','test_orbit_images.mjs','test_generation.mjs','test_accounts.mjs','test_session_races.mjs','test_async_drafts.mjs'])await import('./'+file);
console.log('All six Orbit verification suites passed.');
