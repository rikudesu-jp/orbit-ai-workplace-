import http from 'node:http';
import { readFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';

const page = new URL('./index.html', import.meta.url);
const upstream = 'https://openrouter.ai/api/v1';
function validImage(url, limit=2*1024*1024) {
  if(typeof url!=='string'||url.length>Math.ceil(limit/3)*4+100)return false;
  const match=/^data:image\/(png|jpeg|webp);base64,([A-Za-z0-9+/]+={0,2})$/.exec(url);
  if(!match)return false;
  const bytes=Buffer.from(match[2],'base64');
  if(bytes.length>limit||bytes.length<12)return false;
  return match[1]==='png'?bytes.subarray(0,8).equals(Buffer.from([137,80,78,71,13,10,26,10])):
    match[1]==='jpeg'?bytes[0]===255&&bytes[1]===216&&bytes[2]===255:
    bytes.toString('ascii',0,4)==='RIFF'&&bytes.toString('ascii',8,12)==='WEBP';
}
function validMessage(m){
  if(!m||!['system','user','assistant'].includes(m.role))return false;
  if(typeof m.content==='string')return m.content.length<=262144;
  return m.role==='user'&&Array.isArray(m.content)&&m.content.length>0&&m.content.length<=2&&
    m.content.every(p=>p&&((p.type==='text'&&typeof p.text==='string'&&p.text.length<=32000)||
      (p.type==='image_url'&&validImage(p.image_url?.url))));
}
export function createApp({key = process.env.OPENROUTER_API_KEY || '', request = fetch, supabaseUrl=process.env.SUPABASE_URL||'', supabaseKey=process.env.SUPABASE_ANON_KEY||'', appOrigin=process.env.APP_ORIGIN||''} = {}) {
  const authEnabled=!!(supabaseUrl&&supabaseKey);
  if(authEnabled){
    if(!/^https:\/\/[^/?#]+$/.test(supabaseUrl))throw Error('SUPABASE_URL must be an HTTPS project origin without a trailing slash.');
    let role='';try{role=JSON.parse(Buffer.from(supabaseKey.split('.')[1]||'','base64url').toString()).role}catch{}
    if(supabaseKey.startsWith('sb_secret_')||role==='service_role')throw Error('Use the Supabase publishable or anon key, never a service-role or secret key.');
  }
  if(appOrigin&&!authEnabled)throw Error('Public hosting requires Supabase authentication. Configure SUPABASE_URL and SUPABASE_ANON_KEY first.');
  if(appOrigin&&!appOrigin.startsWith('https://'))throw Error('APP_ORIGIN must be your HTTPS origin.');
  const assets={'/workspace.css':'text/css','/workspace.js':'text/javascript','/vendor/supabase.js':'text/javascript','/orbit-logo.png':'image/png','/orbit-logo.svg':'image/svg+xml'};
  const rateLimits=new Map();
  const reasoningModels=new Set();
  let running = false;
  const json = (res, code, data) => {res.writeHead(code, {'Content-Type':'application/json','Cache-Control':'no-store'});res.end(JSON.stringify(data));};
  return http.createServer(async (req, res) => {
    res.setHeader('X-Content-Type-Options','nosniff');
    res.setHeader('Referrer-Policy','no-referrer');
    res.setHeader('X-Frame-Options','DENY');
    const host = req.headers.host || '';
    if (appOrigin?host!==new URL(appOrigin).host:!/^(localhost|127\.0\.0\.1)(:\d+)?$/.test(host)) return json(res,403,{error:'This host is not configured.'});
    const origin = req.headers.origin;
    if (origin && origin !== (appOrigin||`http://${host}`)) return json(res,403,{error:'Cross-origin requests are not allowed.'});
    const url = new URL(req.url, `http://${host}`);
    try {
      if(req.method==='GET'&&assets[url.pathname]){res.writeHead(200,{'Content-Type':assets[url.pathname],'Cache-Control':'no-cache'});return res.end(await readFile(new URL('.'+url.pathname,import.meta.url)));}
      if(req.method==='GET'&&url.pathname==='/api/config')return json(res,200,{authEnabled,supabaseUrl:authEnabled?supabaseUrl:'',supabaseKey:authEnabled?supabaseKey:''});
      if(req.method === 'GET' && url.pathname === '/') {
        res.writeHead(200,{'Content-Type':'text/html;charset=utf-8','Cache-Control':'no-store'});
        return res.end(await readFile(page));
      }
      if(req.method === 'GET' && url.pathname === '/api/status') return json(res,200,{configured:!!key});
      if(req.method === 'GET' && url.pathname === '/api/image-models') {
        const response=await request(upstream+'/images/models',{signal:AbortSignal.timeout(20000)});
        if(!response.ok)return json(res,502,{error:'Image model catalog unavailable. Please retry.'});
        const result=await response.json();
        return json(res,200,{configured:!!key,models:(result.data||[]).map(m=>({name:m.id,label:m.name,vision:m.architecture?.input_modalities?.includes('image')===true}))});
      }
      if(req.method === 'GET' && url.pathname === '/api/models') {
        const response=await request(upstream+'/models',{signal:AbortSignal.timeout(20000)});
        if(!response.ok) return json(res,502,{error:'OpenRouter model catalog is unavailable. Please retry.'});
        const result=await response.json();
        const models=(result.data || []).filter(m=>m.architecture?.output_modalities?.length===1 && m.architecture.output_modalities[0]==='text' && !/\(batch\)/i.test(m.name||''))
          .map(m=>{const reasoning=m.supported_parameters?.includes('reasoning')===true||m.supported_parameters?.includes('reasoning_effort')===true;if(reasoning)reasoningModels.add(m.id);return {name:m.id,label:m.name,context:m.context_length,pricing:m.pricing,reasoning,vision:m.architecture?.input_modalities?.includes('image')===true}});
        return json(res,200,{models,configured:!!key});
      }
      let user=null,authHeaders;
      if(authEnabled&&['/api/chat','/api/images','/api/state'].includes(url.pathname)){
        const token=req.headers.authorization;
        if(!token?.startsWith('Bearer ')||token.length>8192)return json(res,401,{error:'Sign in to your account first.'});
        authHeaders={apikey:supabaseKey,Authorization:token,'Content-Type':'application/json'};
        const verified=await request(supabaseUrl+'/auth/v1/user',{headers:authHeaders,signal:AbortSignal.timeout(15000)});
        if(!verified.ok)return json(res,401,{error:'Your session expired. Please sign in again.'});
        user=await verified.json();if(typeof user.id!=='string'||!user.id)return json(res,401,{error:'Invalid account session.'});
      }
      if(url.pathname==='/api/state'){
        if(!user)return json(res,401,{error:'Accounts are not configured.'});
        const stateUrl=supabaseUrl+'/rest/v1/orbit_workspaces?user_id=eq.'+encodeURIComponent(user.id);
        if(req.method==='GET'){
          const r=await request(stateUrl+'&select=payload,revision',{headers:authHeaders,signal:AbortSignal.timeout(15000)});
          if(!r.ok)return json(res,502,{error:'Cloud history unavailable. Check that the database setup has been applied.'});
          const rows=await r.json();return json(res,200,rows[0]||{payload:null,revision:0});
        }
        if(req.method==='PUT'){
          let raw='';for await(const chunk of req){raw+=chunk;if(Buffer.byteLength(raw)>12*1024*1024)return json(res,413,{error:'Cloud history is full. Export or delete older conversations.'});}
          let data;try{data=JSON.parse(raw)}catch{return json(res,400,{error:'Invalid workspace data.'})}
          if(!data||!Number.isSafeInteger(data.revision)||data.revision<0||!data.payload||!Array.isArray(data.payload.chats)||data.payload.chats.length>500||!data.payload.preferences||typeof data.payload.preferences!=='object')return json(res,400,{error:'Invalid workspace data.'});
          const fresh=data.revision===0;
          const target=fresh?supabaseUrl+'/rest/v1/orbit_workspaces':stateUrl+'&revision=eq.'+data.revision;
          const r=await request(target,{method:fresh?'POST':'PATCH',headers:{...authHeaders,Prefer:'return=representation'},body:JSON.stringify({...(fresh?{user_id:user.id}:{}),payload:data.payload,revision:data.revision+1}),signal:AbortSignal.timeout(15000)});
          if(r.status===409)return json(res,409,{error:'Another device updated this workspace. Reload cloud history before saving.'});
          if(!r.ok)return json(res,502,{error:'Cloud save failed. Your changes remain in this session; retry saving or export before leaving.'});
          const rows=await r.json();if(!rows.length)return json(res,409,{error:'Another device updated this workspace. Reload cloud history before saving.'});
          return json(res,200,{revision:data.revision+1});
        }
        return json(res,405,{error:'Method not allowed.'});
      }
      if(req.method !== 'POST' || !['/api/chat','/api/images'].includes(url.pathname)) return json(res,404,{error:'Not found.'});
      if(!key) return json(res,503,{error:'Add your OpenRouter key to the server’s .env file and restart. Never paste a key into chat.'});
      if(user){const now=Date.now();for(const [id,limit]of rateLimits)if(now>limit.until)rateLimits.delete(id);const limit=rateLimits.get(user.id)||{count:0,until:now+3600000};if(limit.count>=30)return json(res,429,{error:'Your account has reached the 30 requests per hour limit.'});limit.count++;rateLimits.set(user.id,limit);}
      if(!req.headers['content-type']?.startsWith('application/json')) return json(res,415,{error:'JSON required.'});
      let body='';
      for await(const chunk of req){body+=chunk;if(Buffer.byteLength(body)>12*1024*1024)return json(res,413,{error:'This conversation has too much text or image data. Start a new chat.'});}
      let input;try{input=JSON.parse(body)}catch{return json(res,400,{error:'Invalid JSON.'})}
      if(!input||typeof input!=='object')return json(res,400,{error:'Invalid request.'});
      if(url.pathname==='/api/images'){
        if(typeof input.model!=='string'||!input.model||input.model.length>180||typeof input.prompt!=='string'||!input.prompt.trim()||input.prompt.length>32000||(input.image&&!validImage(input.image)))return json(res,400,{error:'Choose an image model, write a prompt, and use a supported reference image.'});
        if(running)return json(res,429,{error:'Another request is running. Please wait.'});
        running=true;const abort=new AbortController();const timer=setTimeout(()=>abort.abort(),290000);res.on('close',()=>abort.abort());
        try{
          const payload={model:input.model,prompt:input.prompt,n:1};
          if(input.image)payload.input_references=[{type:'image_url',image_url:{url:input.image}}];
          const response=await request(upstream+'/images',{method:'POST',headers:{Authorization:`Bearer ${key}`,'Content-Type':'application/json','X-Title':'Orbit AI Workspace'},body:JSON.stringify(payload),signal:abort.signal});
          if(!response.ok)return json(res,response.status,{error:response.status===402?'Insufficient OpenRouter credits.':`Image generation failed (HTTP ${response.status}). Check model access, credits, or try another model.`});
          const result=await response.json();
          const images=(result.data||[]).slice(0,4).map(item=>({url:`data:${item.media_type||'image/png'};base64,${item.b64_json||''}`})).filter(item=>validImage(item.url,20*1024*1024));
          if(!images.length)return json(res,502,{error:'No supported raster image was returned. Try a PNG/JPEG/WebP image model.'});
          return json(res,200,{images});
        }catch{if(!res.destroyed)json(res,502,{error:'Image generation was interrupted or timed out. Check OpenRouter usage before retrying; a stopped request may still be billed.'});}
        finally{clearTimeout(timer);running=false;}
        return;
      }
      if(typeof input.model!=='string'||input.model.length>180||!Array.isArray(input.messages)||!input.messages.length||input.messages.length>200||input.messages.some(m=>!validMessage(m)))return json(res,400,{error:'Invalid message or image. Use PNG, JPEG, or WebP up to 2 MB each.'});
      if(running)return json(res,429,{error:'Another response is running. Please wait.'});
      running=true;
      const abort=new AbortController();
      const timer=setTimeout(()=>abort.abort(),290000);
      res.on('close',()=>abort.abort());
      try{
        const response=await request(upstream+'/chat/completions',{
          method:'POST',headers:{Authorization:`Bearer ${key}`,'Content-Type':'application/json','X-Title':'Orbit AI Workspace'},
          body:JSON.stringify({model:input.model,messages:input.messages.map(({role,content})=>({role,content})),stream:true,max_tokens:input.thinking===true&&reasoningModels.has(input.model)?8192:2048,...(input.thinking===true&&reasoningModels.has(input.model)?{reasoning:{effort:'medium',exclude:true}}:{})}),signal:abort.signal});
        if(!response.ok){const errors={401:'The OpenRouter key was rejected.',402:'Insufficient OpenRouter credits.',429:'OpenRouter rate limit reached. Try again later.'};return json(res,response.status,{error:errors[response.status]||`OpenRouter could not complete the request (HTTP ${response.status}). Try another model.`});}
        if(!response.body)throw Error('Missing upstream stream');
        res.writeHead(200,{'Content-Type':'application/x-ndjson','Cache-Control':'no-store'});
        const decoder=new TextDecoder();let pending='';
        function line(raw){const text=raw.trim();if(!text.startsWith('data:'))return;const payload=text.slice(5).trim();if(!payload||payload==='[DONE]')return;const event=JSON.parse(payload);if(event.error){res.write(JSON.stringify({error:'The model provider interrupted the response. Try again.'})+'\n');return;}const content=event.choices?.[0]?.delta?.content;if(typeof content==='string'&&content)res.write(JSON.stringify({message:{content}})+'\n');}
        for await(const chunk of response.body){pending+=decoder.decode(chunk,{stream:true});let i;while((i=pending.indexOf('\n'))!==-1){line(pending.slice(0,i));pending=pending.slice(i+1);}}
        pending+=decoder.decode();if(pending.trim())line(pending);res.end();
      }catch{if(!res.destroyed){if(res.headersSent){res.end(JSON.stringify({error:'Connection interrupted or timed out. Try again.'})+'\n')}else json(res,502,{error:'Could not reach OpenRouter. Check your connection and retry.'});}}
      finally{clearTimeout(timer);running=false;}
    }catch{if(!res.headersSent)json(res,500,{error:'The server could not process the request.'});else res.end();}
  });
}
if(process.argv[1] === fileURLToPath(import.meta.url)) {
  const port=Number(process.env.PORT||3000);
  createApp().listen(port,process.env.APP_ORIGIN?'0.0.0.0':'127.0.0.1',()=>console.log(`Orbit: ${process.env.APP_ORIGIN||'http://127.0.0.1:'+port}\nOpenRouter key: ${process.env.OPENROUTER_API_KEY?'configured':'not configured — see README.txt'}`));
}
